class RenderMesh{
    constructor(matrix,mesh){
        this.matrix = matrix;
        this.mesh = mesh;
    }
    
}