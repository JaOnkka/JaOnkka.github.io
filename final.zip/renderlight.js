class RenderLight{
    constructor(matrix, light){
        this.matrix = matrix;
        this.light = light;
    }
}